// 驱动对接.h - 完整修复版本
#ifndef DRIVER_INTERFACE_H
#define DRIVER_INTERFACE_H

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <iostream>
#include <cstdint>

// ==================== 驱动类型定义 ====================
enum DriverType {
    DRIVER_KMA = 1,      // KMA驱动（使用driver.h）
    DRIVER_QX_1 = 2,     // QX驱动1（读取慢,兼容性高）
    DRIVER_GT = 3,       // GT驱动
    DRIVER_RT_DEV = 4,   // rt-dev驱动
    DRIVER_RT_PROC = 5,  // rt-proc驱动
    DRIVER_QX_2 = 6      // QX驱动2
};

// IOCTL操作定义（用于非KMA驱动）
enum OPERATIONS {
    OP_INIT_KEY = 0x800,
    OP_READ_MEM = 0x801,
    OP_WRITE_MEM = 0x802,
    OP_MODULE_BASE = 0x803,
};

// 内存复制结构体（用于非KMA驱动）
typedef struct _COPY_MEMORY {
    pid_t pid;
    uintptr_t addr;
    void* buffer;
    size_t size;
} COPY_MEMORY, *PCOPY_MEMORY;

// 模块基址结构体（用于非KMA驱动）
typedef struct _MODULE_BASE {
    pid_t pid;
    char* name;
    uintptr_t base;
} MODULE_BASE, *PMODULE_BASE;

// ==================== 重命名driver.h中的Driver类 ====================
#define OriginalDriver Driver
#include "driver.h"
#undef Driver

// ==================== DriverInterface类 ====================
class DriverInterface
{
private:
    DriverType current_type;
    int fd;
    pid_t current_pid;
    OriginalDriver* kma_driver;
    
    // ==================== 辅助方法 ====================
    char *execCom(const char *shell) {
        FILE *fp = popen(shell, "r");
        if (fp == NULL) return NULL;
        char buffer[256];
        char *result = (char *)malloc(1000);
        result[0] = '\0';
        while (fgets(buffer, sizeof(buffer), fp) != NULL) {
            strcat(result, buffer);
        }
        pclose(fp);
        return result;
    }
    
    void createDriverNode(char *path, int major_number, int minor_number) {
        std::string command = "mknod " + std::string(path) + " c " + 
                             std::to_string(major_number) + " " + std::to_string(minor_number);
        system(command.c_str());
    }
    
    const char* get_dev_qx1() {
        const char* command = "for dir in /proc/*/; do cmdline_file=\"cmdline\"; comm_file=\"comm\"; proclj=\"$dir$cmdline_file\"; proclj2=\"$dir$comm_file\"; if [[ -f \"$proclj\" && -f \"$proclj2\" ]]; then cmdline=$(head -n 1 \"$proclj\"); comm=$(head -n 1 \"$proclj2\"); if echo \"$cmdline\" | grep -qE '^/data/[a-z]{6}$'; then sbwj=$(echo \"$comm\"); open_file=\"\"; for file in \"$dir\"/fd/*; do link=$(readlink \"$file\"); if [[ \"$link\" == \"/dev/$sbwj (deleted)\" ]]; then open_file=\"$file\"; break; fi; done; if [[ -n \"$open_file\" ]]; then nhjd=$(echo \"$open_file\"); sbid=$(ls -L -l \"$nhjd\" | sed 's/\\([^,]*\\).*/\\1/' | sed 's/.*root //'); echo \"/dev/$sbwj\"; rm -Rf \"/dev/$sbwj\"; mknod \"/dev/$sbwj\" c \"$sbid\" 0; break; fi; fi; fi; done";
        
        FILE* file = popen(command, "r");
        if (file == NULL) return NULL;
        static char result[512];
        if (fgets(result, sizeof(result), file) == NULL) {
            pclose(file);
            return NULL;
        }
        pclose(file);
        int len = strlen(result);
        if (len > 0 && result[len - 1] == '\n') {
            result[len - 1] = '\0';
        }
        return strdup(result);
    }
    
    char *gtqwq() {
        const char *dev_path = "/dev";
        DIR *dir = opendir(dev_path);
        if (dir == NULL) return NULL;
        const char *files[] = { "wanbai", "CheckMe", "Ckanri", "lanran", "video188" };
        struct dirent *entry;
        char *gtfile_path = NULL;
        while ((entry = readdir(dir)) != NULL) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
                continue;
            }
            size_t path_length = strlen(dev_path) + strlen(entry->d_name) + 2;
            gtfile_path = (char *)malloc(path_length);
            snprintf(gtfile_path, path_length, "%s/%s", dev_path, entry->d_name);
            for (int i = 0; i < 5; i++) {
                if (strcmp(entry->d_name, files[i]) == 0) {
                    closedir(dir);
                    return gtfile_path;
                }
            }
            struct stat file_info;
            if (stat(gtfile_path, &file_info) < 0) {
                free(gtfile_path);
                gtfile_path = NULL;
                continue;
            }
            if (strstr(entry->d_name, "gpiochip") != NULL) {
                free(gtfile_path);
                gtfile_path = NULL;
                continue;
            }
            if ((S_ISCHR(file_info.st_mode) || S_ISBLK(file_info.st_mode))
                && strchr(entry->d_name, '_') == NULL 
                && strchr(entry->d_name, '-') == NULL 
                && strchr(entry->d_name, ':') == NULL) {
                if (strcmp(entry->d_name, "stdin") == 0 
                    || strcmp(entry->d_name, "stdout") == 0
                    || strcmp(entry->d_name, "stderr") == 0) {
                    free(gtfile_path);
                    gtfile_path = NULL;
                    continue;
                }
                size_t file_name_length = strlen(entry->d_name);
                time_t current_time;
                time(&current_time);
                int current_year = localtime(&current_time)->tm_year + 1900;
                int file_year = localtime(&file_info.st_ctime)->tm_year + 1900;
                if (file_year <= 1980) {
                    free(gtfile_path);
                    gtfile_path = NULL;
                    continue;
                }
                time_t atime = file_info.st_atime;
                time_t ctime = file_info.st_ctime;
                if (atime == ctime) {
                    if ((file_info.st_mode & S_IFMT) == 8192 
                        && file_info.st_size == 0
                        && file_info.st_gid == 0 
                        && file_info.st_uid == 0 
                        && file_name_length <= 9) {
                        closedir(dir);
                        return gtfile_path;
                    }
                }
            }
            free(gtfile_path);
            gtfile_path = NULL;
        }
        closedir(dir);
        return NULL;
    }
    
    char *find_driver_path() {
        const char *dev_path = "/dev";
        DIR *dir = opendir(dev_path);
        if (dir == NULL) return NULL;
        const char *files[] = {"wanbai","CheckMe","Ckanri","lanran","video188"};
        struct dirent *entry;
        char *file_path = NULL;
        while ((entry = readdir(dir)) != NULL) {
            if (strcmp(entry->d_name, ".") == 0 
                || strcmp(entry->d_name, "..") == 0 
                || strcmp(entry->d_name, "wanbai") == 0 
                || strcmp(entry->d_name, "CheckMe") == 0 
                || strcmp(entry->d_name, "facking") == 0 
                || strcmp(entry->d_name, "vndbinder") == 0 
                || strcmp(entry->d_name, "YBBBYN") == 0) {
                continue;
            }
            size_t path_length = strlen(dev_path) + strlen(entry->d_name) + 2;
            file_path = (char *)malloc(path_length);
            snprintf(file_path, path_length, "%s/%s", dev_path, entry->d_name);
            for (int i = 0; i < 5; i++) {
                if (strcmp(entry->d_name, files[i]) == 0) {
                    closedir(dir);
                    return file_path;
                }
            }
            struct stat file_info;
            if (stat(file_path, &file_info) < 0) {
                free(file_path);
                file_path = NULL;
                continue;
            }
            if (strstr(entry->d_name, "gpiochip") != NULL) {
                free(file_path);
                file_path = NULL;
                continue;
            }
            if ((S_ISCHR(file_info.st_mode) || S_ISBLK(file_info.st_mode))
                && strchr(entry->d_name, '_') == NULL 
                && strchr(entry->d_name, '-') == NULL 
                && strchr(entry->d_name, ':') == NULL) {
                if (strcmp(entry->d_name, "stdin") == 0 
                    || strcmp(entry->d_name, "stdout") == 0
                    || strcmp(entry->d_name, "stderr") == 0) {
                    free(file_path);
                    file_path = NULL;
                    continue;
                }
                size_t file_name_length = strlen(entry->d_name);
                time_t current_time;
                time(&current_time);
                int current_year = localtime(&current_time)->tm_year + 1900;
                int file_year = localtime(&file_info.st_ctime)->tm_year + 1900;
                if (file_year <= 1980) {
                    free(file_path);
                    file_path = NULL;
                    continue;
                }
                time_t atime = file_info.st_atime;
                time_t ctime = file_info.st_ctime;
                if (atime == ctime) {
                    if ((file_info.st_mode & S_IFMT) == 8192 
                        && file_info.st_size == 0
                        && file_info.st_gid == 0 
                        && file_info.st_uid == 0 
                        && file_name_length <= 9) {
                        closedir(dir);
                        return file_path;
                    }
                }
            }
            free(file_path);
            file_path = NULL;
        }
        closedir(dir);
        return NULL;
    }
    
    char *driver_path_alt() {
        struct dirent *de;
        DIR *dr = opendir("/proc");
        char *device_path = NULL;
        if (dr == NULL) return NULL;
        while ((de = readdir(dr)) != NULL) {
            if (strlen(de->d_name) != 8 
                || strcmp(de->d_name, "zoneinfo") == 0 
                || strcmp(de->d_name, "softirqs") == 0 
                || strcmp(de->d_name, "kallsyms") == 0 
                || strcmp(de->d_name, "consoles") == 0 
                || strcmp(de->d_name, "vmstat") == 0 
                || strcmp(de->d_name, "uptime") == 0 
                || strcmp(de->d_name, "NVTSPI") == 0 
                || strcmp(de->d_name, "aputag") == 0 
                || strcmp(de->d_name, "asound") == 0 
                || strcmp(de->d_name, "clkdbg") == 0 
                || strcmp(de->d_name, "crypto") == 0 
                || strcmp(de->d_name, "mounts") == 0 
                || strcmp(de->d_name, "pidmap") == 0 
                || strcmp(de->d_name, "bootprof") == 0) {
                continue;
            }
            int is_valid = 1;
            for (int i = 0; i < 8; i++) {
                if (!isalnum(de->d_name[i])) {
                    is_valid = 0;
                    break;
                }
            }
            if (is_valid) {
                device_path = (char*)malloc(11 + strlen(de->d_name));
                sprintf(device_path, "/proc/%s", de->d_name);
                struct stat sb;
                if (stat(device_path, &sb) == 0 && S_ISREG(sb.st_mode)) {
                    break;
                } else {
                    free(device_path);
                    device_path = NULL;
                }
            }
        }
        closedir(dr);
        return device_path;
    }
    
    uintptr_t get_module_base_maps(pid_t pid, const char* module_name) {
        FILE *fp;
        uintptr_t addr = 0;
        char filename[64];
        char line[1024];
        snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
        fp = fopen(filename, "r");
        if (fp != NULL) {
            while (fgets(line, sizeof(line), fp)) {
                if (strstr(line, module_name)) {
                    char *pch = strtok(line, "-");
                    addr = strtoul(pch, NULL, 16);
                    if (addr == 0x8000) addr = 0;
                    break;
                }
            }
            fclose(fp);
        }
        return addr;
    }
    
    pid_t get_pid_system(const char* name) {
        int id = -1;
        DIR *dir;
        FILE *fp;
        char filename[64];
        char cmdline[64];
        struct dirent *entry;
        dir = opendir("/proc");
        if (dir == NULL) return -1;
        while ((entry = readdir(dir)) != NULL) {
            id = atoi(entry->d_name);
            if (id != 0) {
                sprintf(filename, "/proc/%d/cmdline", id);
                fp = fopen(filename, "r");
                if (fp) {
                    fgets(cmdline, sizeof(cmdline), fp);
                    fclose(fp);
                    if (strcmp(name, cmdline) == 0) {
                        closedir(dir);
                        return id;
                    }
                }
            }
        }
        closedir(dir);
        return -1;
    }
    
    // ==================== 驱动初始化方法 ====================
    bool init_kma() {
        std::cout << "\033[35m[-]\033[33m 初始化KMA驱动...\033[0m" << std::endl;
        try {
            kma_driver = new OriginalDriver();
            if (kma_driver && kma_driver->gid != 0) {
                std::cout << "\033[32m[+]\033[36m KMA驱动初始化成功! GID: " 
                         << std::hex << kma_driver->gid << std::dec << "\033[0m" << std::endl;
                return true;
            } else {
                std::cout << "\033[31m[!]\033[33m KMA驱动初始化失败 (gid=0)\033[0m" << std::endl;
                if (kma_driver) {
                    delete kma_driver;
                    kma_driver = nullptr;
                }
                return false;
            }
        } catch (const std::exception& e) {
            std::cout << "\033[31m[!]\033[33m KMA驱动初始化异常: " << e.what() << "\033[0m" << std::endl;
            return false;
        } catch (...) {
            std::cout << "\033[31m[!]\033[33m KMA驱动初始化未知异常\033[0m" << std::endl;
            return false;
        }
    }
    
    bool init_qx1() {
        std::cout << "\033[35m[-]\033[33m 初始化QX驱动1...\033[0m" << std::endl;
        const char* dev_path = get_dev_qx1();
        if (dev_path) {
            fd = open(dev_path, O_RDWR);
            if (fd > 0) {
                std::cout << "\033[32m[+]\033[36m QX驱动1打开成功: " << dev_path << "\033[0m" << std::endl;
                unlink(dev_path);
                free((void*)dev_path);
                return true;
            }
            free((void*)dev_path);
        }
        std::cout << "\033[31m[!]\033[33m QX驱动1初始化失败\033[0m" << std::endl;
        return false;
    }
    
    bool init_gt() {
        std::cout << "\033[35m[-]\033[33m 初始化GT驱动...\033[0m" << std::endl;
        char *device_name = gtqwq();
        if (device_name) {
            fd = open(device_name, O_RDWR);
            if (fd > 0) {
                std::cout << "\033[32m[+]\033[36m GT驱动打开成功: " << device_name << "\033[0m" << std::endl;
                free(device_name);
                return true;
            }
            free(device_name);
        }
        std::cout << "\033[31m[!]\033[33m GT驱动初始化失败\033[0m" << std::endl;
        return false;
    }
    
    bool init_rt_dev() {
        std::cout << "\033[35m[-]\033[33m 初始化rt-dev驱动...\033[0m" << std::endl;
        char *device_name = find_driver_path();
        if (!device_name) {
            device_name = find_driver_path();
        }
        if (device_name) {
            fd = open(device_name, O_RDWR);
            if (fd > 0) {
                std::cout << "\033[32m[+]\033[36m rt-dev驱动打开成功: " << device_name << "\033[0m" << std::endl;
                free(device_name);
                return true;
            }
            free(device_name);
        }
        std::cout << "\033[31m[!]\033[33m rt-dev驱动初始化失败\033[0m" << std::endl;
        return false;
    }
    
    bool init_rt_proc() {
        std::cout << "\033[35m[-]\033[33m 初始化rt-proc驱动...\033[0m" << std::endl;
        char *device_name = driver_path_alt();
        if (device_name) {
            fd = open(device_name, O_RDWR);
            if (fd > 0) {
                std::cout << "\033[32m[+]\033[36m rt-proc驱动打开成功\033[0m" << std::endl;
                free(device_name);
                return true;
            }
            free(device_name);
        }
        std::cout << "\033[31m[!]\033[33m rt-proc驱动初始化失败\033[0m" << std::endl;
        return false;
    }
    
    bool init_qx2() {
        std::cout << "\033[35m[-]\033[33m 初始化QX驱动2...\033[0m" << std::endl;
        char *output = execCom("ls -l /proc/*/exe 2>/dev/null | grep -E \"/data/[a-z]{6} \\(deleted\\)\"");
        char filePath[256] = {0};
        char pid[56] = {0};
        if (output != NULL) {
            char *procStart = strstr(output, "/proc/");
            if (procStart) {
                char *pidStart = procStart + 6;
                char *pidEnd = strchr(pidStart, '/');
                if (pidEnd) {
                    strncpy(pid, pidStart, pidEnd - pidStart);
                    pid[pidEnd - pidStart] = '\0';
                }
            }
            char *arrowStart = strstr(output, "->");
            if (arrowStart) {
                char *start = arrowStart + 3;
                char *end = strchr(output, '(');
                if (end) {
                    end--;
                    strncpy(filePath, start, end - start + 1);
                    filePath[end - start] = '\0';
                }
            }
            char *replacePtr = strstr(filePath, "data");
            if (replacePtr != NULL) {
                memmove(replacePtr + 2, replacePtr + 3, strlen(replacePtr + 3) + 1);
                memmove(replacePtr, "dev", strlen("dev"));
            }
            free(output);
        } else {
            std::cout << "\033[31m[!]\033[33m 执行脚本失败\033[0m" << std::endl;
            return false;
        }
        char cmd[256];
        sprintf(cmd, "ls -al -L /proc/%s/fd/3", pid);
        char *fdInfo = execCom(cmd);
        int major_number = 0, minor_number = 0;
        if (fdInfo) {
            sscanf(fdInfo, "%*s %*d %*s %*s %d, %d", &major_number, &minor_number);
            free(fdInfo);
        }
        if (strcmp(filePath, "0") != 0) {
            std::string mknod_cmd = "mknod " + std::string(filePath) + " c " + 
                                   std::to_string(major_number) + " " + std::to_string(minor_number);
            system(mknod_cmd.c_str());
        }
        sleep(1);
        fd = open(filePath, O_RDWR);
        if (fd > 0) {
            std::cout << "\033[32m[+]\033[36m QX驱动2打开成功: " << filePath << "\033[0m" << std::endl;
            unlink(filePath);
            return true;
        }
        std::cout << "\033[31m[!]\033[33m QX驱动2初始化失败\033[0m" << std::endl;
        return false;
    }
    
public:
    DriverInterface(DriverType type = DRIVER_KMA) 
        : current_type(type), fd(-1), current_pid(0), kma_driver(nullptr)
    {
        std::cout << "\033[35m[-]\033[33m 初始化驱动类型: ";
        bool init_success = false;
        switch(type) {
            case DRIVER_KMA:
                std::cout << "KMA驱动\033[0m" << std::endl;
                init_success = init_kma();
                break;
            case DRIVER_QX_1:
                std::cout << "QX驱动1\033[0m" << std::endl;
                init_success = init_qx1();
                break;
            case DRIVER_GT:
                std::cout << "GT驱动\033[0m" << std::endl;
                init_success = init_gt();
                break;
            case DRIVER_RT_DEV:
                std::cout << "rt-dev驱动\033[0m" << std::endl;
                init_success = init_rt_dev();
                break;
            case DRIVER_RT_PROC:
                std::cout << "rt-proc驱动\033[0m" << std::endl;
                init_success = init_rt_proc();
                break;
            case DRIVER_QX_2:
                std::cout << "QX驱动2\033[0m" << std::endl;
                init_success = init_qx2();
                break;
            default:
                std::cout << "\033[31m[!]\033[33m 未知驱动类型\033[0m" << std::endl;
                break;
        }
        if (init_success) {
            std::cout << "\033[32m[+]\033[36m 驱动初始化完成\033[0m" << std::endl;
        } else {
            std::cout << "\033[31m[!]\033[33m 驱动初始化失败\033[0m" << std::endl;
        }
    }
    
    ~DriverInterface() {
        destroy();
        if (fd > 0) close(fd);
        if (kma_driver) {
            delete kma_driver;
            kma_driver = nullptr;
        }
    }
    
    void initpid(pid_t pid) {
        current_pid = pid;
        std::cout << "\033[35m[-]\033[33m 设置当前PID: " << pid << "\033[0m" << std::endl;
        if (current_type == DRIVER_KMA && kma_driver) {
            kma_driver->initpid(pid);
        }
    }
    
    pid_t get_pid(const char* name) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->get_pid(const_cast<char*>(name));
        }
        return get_pid_system(name);
    }
    
    pid_t get_pid(const char* name, const char* comm) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->get_pid(const_cast<char*>(name), const_cast<char*>(comm));
        }
        return get_pid_system(name);
    }
    
    uintptr_t get_module_base(pid_t pid, const char* name) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->get_module_base(pid, const_cast<char*>(name));
        } else if (fd > 0) {
            MODULE_BASE mb;
            mb.pid = pid;
            mb.name = strdup(name);
            uintptr_t base = 0;
            if (ioctl(fd, OP_MODULE_BASE, &mb) == 0) {
                base = mb.base;
            }
            free(mb.name);
            return base;
        }
        return get_module_base_maps(pid, name);
    }
    
    uintptr_t get_module_base(pid_t pid, const char* name, size_t size) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->get_module_base(pid, const_cast<char*>(name), size);
        } else {
            return get_module_base(pid, name);
        }
    }
    
    bool read(uintptr_t addr, void* buffer, size_t size) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->read(addr, buffer, size);
        } else if (fd > 0 && current_pid > 0) {
            COPY_MEMORY cm;
            cm.pid = current_pid;
            cm.addr = addr;
            cm.buffer = buffer;
            cm.size = size;
            return (ioctl(fd, OP_READ_MEM, &cm) == 0);
        }
        return false;
    }
    
    template <typename T>
    T read(uintptr_t addr) {
        T res{};
        if (this->read(addr, &res, sizeof(T)))
            return res;
        return {};
    }
    
    bool write(uintptr_t addr, void* buffer, size_t size) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->write(addr, buffer, size);
        } else if (fd > 0 && current_pid > 0) {
            COPY_MEMORY cm;
            cm.pid = current_pid;
            cm.addr = addr;
            cm.buffer = buffer;
            cm.size = size;
            return (ioctl(fd, OP_WRITE_MEM, &cm) == 0);
        }
        return false;
    }
    
    template <typename T>
    bool write(uintptr_t addr, T value) {
        return this->write(addr, &value, sizeof(T));
    }
    
    bool read_safe(uintptr_t addr, void* buffer, size_t size) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->read_safe(addr, buffer, size);
        }
        return read(addr, buffer, size);
    }
    
    template <typename T>
    T read_safe(uintptr_t addr) {
        T res{};
        if (this->read_safe(addr, &res, sizeof(T)))
            return res;
        return {};
    }
    
    void destroy() {
        if (current_type == DRIVER_KMA && kma_driver) {
            kma_driver->destroy();
        }
        if (fd > 0) {
            close(fd);
            fd = -1;
        }
        std::cout << "\033[35m[-]\033[33m 驱动资源已释放\033[0m" << std::endl;
    }
    
    bool is_valid() {
        if (current_type == DRIVER_KMA) {
            return kma_driver != nullptr && kma_driver->gid != 0;
        } else {
            return fd > 0;
        }
    }
    
    DriverType get_driver_type() const {
        return current_type;
    }
    
    pid_t get_current_pid() const {
        return current_pid;
    }
    
    void cpuset(int num) {
        if (current_type == DRIVER_KMA && kma_driver) {
            kma_driver->cpuset(num);
        }
    }
    
    void cpuset(int start, int end) {
        if (current_type == DRIVER_KMA && kma_driver) {
            kma_driver->cpuset(start, end);
        }
    }
    
    bool uinput_init(int width, int height) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->uinput_init(width, height);
        }
        return false;
    }
    
    void uinput_move(int x, int y) {
        if (current_type == DRIVER_KMA && kma_driver) {
            kma_driver->uinput_move(x, y);
        }
    }
    
    void uinput_down(int x, int y) {
        if (current_type == DRIVER_KMA && kma_driver) {
            kma_driver->uinput_down(x, y);
        }
    }
    
    void uinput_up() {
        if (current_type == DRIVER_KMA && kma_driver) {
            kma_driver->uinput_up();
        }
    }
    
    int uinput_rand(int val) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->uinput_rand(val);
        }
        return val;
    }
    
    int uinput_rand(int val, int rand_val) {
        if (current_type == DRIVER_KMA && kma_driver) {
            return kma_driver->uinput_rand(val, rand_val);
        }
        return val;
    }
};

#endif // DRIVER_INTERFACE_H