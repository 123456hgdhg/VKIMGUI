/*
识别进程 = 2;        //和平精英
//0x5a28) + 0x658) + 0x650 相机
#define Matrix_Offset getPtr64(getPtr64(libbase + 0x13709340) + 0x20) + 0x270
#define Fov_Offset getFloat(getPtr64(getPtr64(MySelf + 0x5a28) + 0x658) + 0x680)
#define Firing_Offset getDword(MySelf + 0x2548)
#define Aiming_Offset getDword(MySelf + 0x1770)
#define MyWeapon_Offset getDword(getPtr64(MySelf + 0x10c8) + 0xca0)
#define Gname_Offset getPtr64(libbase + 0x12f60b48)
#define Uleve_Offset getPtr64(MySelf + 0x20)
#define Arrayaddr_Offset getPtr64(Uleve + 0xA0)
#define Count_Offset getDword(Uleve + 0xA8)
#define MySelf_Offset getPtr64(getPtr64(getPtr64(libbase + 0x13196BE0) + 0x18) + 0x358)//0x7E0 0x388
#define 游戏状态_Offset getPtr64(getPtr64(libbase + 0x1373A758) + 0xaa0)
#define 全局人数_Offset 0x1284
#define 剩余队伍_Offset 0x12f4
#define 剩余玩家_Offset 0x1288
#define Myteam_Offset getDword(MySelf + 0xb68)
#define oneself_Offset getPtr64(MySelf + 0x278) + 0x200
#define enemy_Offset getPtr64(Objaddr + 0x278) + 0x200
#define Removematerials_Offset getFloat(Objaddr + 0x1014)
#define TeamID_Offset getDword(Objaddr + 0xb68)
#define 正常血量_Offset getFloat(Objaddr + 0xfb8)
#define 倒地血量_Offset getFloat(Objaddr + 0x3778)
#define 最大血量_Offset getFloat(Objaddr + 0xfc0)
#define isBot_Offset getbyte(Objaddr + 0xb84) != 0
#define State_Offset getDword(getPtr64(Objaddr + 0x1638))
#define Enemyweapons_Offset getDword(getPtr64(Objaddr + 0x10c8) + 0xca0)
#define 弹夹子弹_Offset getDword(getPtr64(Objaddr + 0x10c8) + 0x1c70)
#define 总备弹量_Offset getDword(getPtr64(Objaddr + 0x10c8) + 0x1c74)
#define name_Offset getPtr64(Objaddr + 0xae8)
#define angle_Offset getFloat(MySelf + 0x1a8)
#define 判断车上_Offset getPtr64(Objaddr + 0x1b8)
#define 车上向量_Offset 0x180
#define vector_Offset getPtr64(Objaddr + 0x278) + 0x250
#define Mesh_Offset getPtr64(Objaddr + 0x650)
#define human_Offset 0x1f0
#define Bone_Offset getPtr64(Mesh + 0x810) + 0x30
#define VehicleData_Offset getPtr64(Objaddr + 0xbb0)
#define 载具血量_Offset getFloat(VehicleData + 0x1f0) / getFloat(VehicleData + 0x1ec) * 100
#define 载具油量_Offset getFloat(VehicleData + 0x214) / getFloat(VehicleData + 0x210) * 100        


#define Uleve_Offset getPtr64(MySelf + 0x20)      // 玩家列表管理器
#define Arrayaddr_Offset getPtr64(Uleve + 0xA0)   // 玩家对象数组
#define Count_Offset getDword(Uleve + 0xA8)       // 玩家总数

自身数据.手持握把 = 读写.getDword(读写.getPtr64(读写.getPtr64(地址.自身地址 + 0x10c8) + 0x1c60) + 0x1ec0);    
自身数据.后坐力数据 = 读写.getFloat(读写.getPtr64(读写.getPtr64(地址.自身地址 + 0x10c8) + 0x1c60) + 0x1dc8);
    
*/


extern int current_game;
static pthread_t data_thread = 0;
static volatile int data_thread_running = 1;
extern DriverInterface* Add;  // 添加这行声明
extern 数据 add;

#include "算法.h"

int 和平精英(){ ////注意这个是和平精英的数据
    add.世界 = Add->read<uintptr_t>(Add->read<uintptr_t>(add.libUE4 + 0x1373a758) + 0xb0);//世界  
    add.Gname = Add->read<uintptr_t>(add.libUE4 + 0x12f60b48);
    add.矩阵_0 = Add->read<uintptr_t>(Add->read<uintptr_t>(add.libUE4 + 0x13709340) + 0x20) + 0x270;
    
    add.自己数据.自身.地址 = Add->read<uintptr_t>(Add->read<uintptr_t>(Add->read<uintptr_t>(Add->read<uintptr_t>(Add->read<uintptr_t>(add.libUE4 +0x1373a758) + 0xb8)+0x88)+0x30)+0x3418);
    
    add.自己数据.自身.坐标.X = Add->read<float>(Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x278) + 0x200);
    add.自己数据.自身.坐标.Y = Add->read<float>(Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x278) + 0x204);
    add.自己数据.自身.坐标.Z = Add->read<float>(Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x278) + 0x208);    
    
    add.自己数据.自身.正常血量 = Add->read<float>(add.自己数据.自身.地址 + 0xfb8);
    add.自己数据.自身.到地血量 = Add->read<float>(add.自己数据.自身.地址 + 0x3778);
    add.自己数据.自身.最大血量 = Add->read<float>(add.自己数据.自身.地址 + 0xfc0);

    add.自己数据.自身.状态 = Add->read<int>(add.自己数据.自身.地址 + 0x1638);
    add.自己数据.自身.当前武器 = Add->read<int>(Add->read<uintptr_t>(Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x3380) + 0x698) + 0xca0);
    add.自己数据.自身.队伍ID = Add->read<int>(add.自己数据.自身.地址 + 0xb68);
    add.自己数据.自身.名字   = Add->read<uintptr_t>(add.自己数据.自身.地址 + 0xae8);
    char* 自己名字 = 读取名字(add.自己数据.自身.名字);
    strncpy(add.自己数据.自身.名字字符串, 自己名字, 63);
    add.自己数据.自身.手持握把 = Add->read<int>(Add->read<uintptr_t>(Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x10c8) + 0x1c60) + 0x1ec0);   
    
    add.自己数据.自身.弹夹子弹 = Add->read<int>(Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x10c8) + 0x1c70);
    add.自己数据.自身.总备弹量 = Add->read<int>(Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x10c8) + 0x1c74);
    
    add.自己数据.自身.人机判断 = Add->read<int>(add.自己数据.自身.地址 + 0xb84); // 判断条件 != 0
    add.自己数据.自身.人物判断 = Add->read<float>(add.自己数据.自身.地址 + 0x1014);
    
    add.自己数据.自身.抑制力   = Add->read<float>(Add->read<uintptr_t>(Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x10c8) + 0x1c60) + 0x1dc8);    
    add.自己数据.自身.准心Y = Add->read<float>(add.自己数据.自身.地址 + 0x1a8);
    add.自己数据.自身.Fov = Add->read<float>(Add->read<uintptr_t>(Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x5a28) + 0x658) + 0x680);
    
    add.自己数据.自身.类名ID = Add->read<int>(add.自己数据.自身.地址 + 24);
    strncpy(add.自己数据.自身.类名, 读取类名(add.自己数据.自身.类名ID, add.Gname), 63);
                 
    // add.当前关卡 = Add->read<uintptr_t>(add.自己数据.自身.地址 + 0x20); // Uleve
    add.对象数组 = Add->read<uintptr_t>(add.世界 + 0xA0); // Arrayaddr
    add.对象数组数量 = Add->read<int>(add.世界 + 0xA8); // Count
    
    // 重置敌人数量计数
    add.对象.敌人数量 = 0;
    
    for (int i = 0; i < add.对象数组数量 && add.对象.敌人数量 < 100; i++){
        add.对象.对象地址 = Add->read<uintptr_t>(add.对象数组 + i * 8);
        add.对象.人物判断 = Add->read<float>(add.对象.对象地址 + 0x1014);        
        add.对象.类名ID = Add->read<int>(add.对象.对象地址 + 24);
        
        
        if (add.对象.人物判断 == 479.5f){          
            敌人结构* 当前敌人 = &add.对象.敌人数组[add.对象.敌人数量];           
            当前敌人->地址 = add.对象.对象地址;
            当前敌人->名字 = Add->read<uintptr_t>(add.对象.对象地址 + 0xae8);
                   
            当前敌人->坐标.X = Add->read<float>(Add->read<uintptr_t>(add.对象.对象地址 + 0x278) + 0x200);
            当前敌人->坐标.Y = Add->read<float>(Add->read<uintptr_t>(add.对象.对象地址 + 0x278) + 0x204);
            当前敌人->坐标.Z = Add->read<float>(Add->read<uintptr_t>(add.对象.对象地址 + 0x278) + 0x208);                   
            
            当前敌人->正常血量 = Add->read<float>(add.对象.对象地址 + 0xfb8);
            当前敌人->到地血量 = Add->read<float>(add.对象.对象地址 + 0x3778);
            当前敌人->最大血量 = Add->read<float>(add.对象.对象地址 + 0xfc0);                                              
            
            当前敌人->弹夹子弹 = Add->read<int>(Add->read<uintptr_t>(add.对象.对象地址 + 0x10c8) + 0x1c70);
            当前敌人->总备弹量 = Add->read<int>(Add->read<uintptr_t>(add.对象.对象地址 + 0x10c8) + 0x1c74);
            
            当前敌人->人机判断 = Add->read<int>(add.对象.对象地址 + 0xb84);
            当前敌人->人物判断 = add.对象.人物判断;//判断 479.5f
            
            当前敌人->状态     = Add->read<int>(add.对象.对象地址 + 0x1638);
            当前敌人->当前武器 = Add->read<int>(Add->read<uintptr_t>(Add->read<uintptr_t>(add.对象.对象地址 + 0x3380) + 0x698) + 0xca0);
            当前敌人->队伍ID   = Add->read<int>(add.对象.对象地址 + 0xb68);
            当前敌人->手持握把 = Add->read<int>(Add->read<uintptr_t>(Add->read<uintptr_t>(add.对象.对象地址 + 0x10c8) + 0x1c60) + 0x1ec0);
            
            当前敌人->类名ID   = add.对象.类名ID;
            strncpy(当前敌人->类名, 读取类名(当前敌人->类名ID, add.Gname), 63);
            
            当前敌人->名字 = Add->read<uintptr_t>(add.对象.对象地址 + 0xae8);
            char* 敌人名字 = 读取名字(当前敌人->名字);
            strncpy(当前敌人->名字字符串, 读取名字(当前敌人->名字), 63);                                                   
                                                                                                                                                                  
            当前敌人->Fov = Add->read<float>(Add->read<uintptr_t>(Add->read<uintptr_t>(add.对象.对象地址 + 0x5a28) + 0x658) + 0x680);
            当前敌人->抑制力 = Add->read<float>(Add->read<uintptr_t>(Add->read<uintptr_t>(add.对象.对象地址 + 0x10c8) + 0x1c60) + 0x1dc8);            
            当前敌人->准心Y = Add->read<float>(add.对象.对象地址 + 0x1a8);
            
            当前敌人->网格地址 = Add->read<uintptr_t>(add.对象.对象地址 + 0x650);
            if (当前敌人->网格地址 > 0) {
                // 1. 获取骨骼组件
                uintptr_t 骨骼组件 = Add->read<uintptr_t>(当前敌人->网格地址 + 0x810);
                
                if (骨骼组件 > 0) {
                    // 2. 骨骼矩阵地址 = 骨骼组件 + 0x30
                    uintptr_t 骨骼矩阵地址 = 骨骼组件 + 0x30;
                    
                    // 3. 获取骨骼数量
                    当前敌人->骨骼点数量 = Add->read<int>(当前敌人->网格地址 + 0x818);
                    if (当前敌人->骨骼点数量 <= 0) 当前敌人->骨骼点数量 = 73; // 常见值
                    if (当前敌人->骨骼点数量 > 128) 当前敌人->骨骼点数量 = 128;
                    
                    // 4. 读取网格变换（应用变换的关键）
                    struct FTransform {
                        float rotation[4];    // 四元数
                        float translation[3]; // 位置
                        float scale[3];       // 缩放
                    } 网格变换;
                    
                    uintptr_t 网格变换地址 = 当前敌人->网格地址 + 0x1f0;
                    bool 有网格变换 = Add->read(网格变换地址, &网格变换, sizeof(FTransform));
                    
                    // 5. 读取所有骨骼坐标（使用4x4矩阵，64字节）
                    for (int i = 0; i < 当前敌人->骨骼点数量; i++) {
                        uintptr_t 骨骼地址 = 骨骼矩阵地址 + (i * 64);
                        
                        float 矩阵[4][4];
                        if (Add->read(骨骼地址, &矩阵, 64)) {
                            // 获取骨骼局部坐标
                            float 局部X = 矩阵[0][3];
                            float 局部Y = 矩阵[1][3];
                            float 局部Z = 矩阵[2][3];
                            
                            // 应用网格变换得到世界坐标
                            float 世界X = 网格变换.translation[0] + 局部X;
                            float 世界Y = 网格变换.translation[1] + 局部Y;
                            float 世界Z = 网格变换.translation[2] + 局部Z;
                            
                            // 保存原始读取的值
                            当前敌人->骨骼点数组[i].位置.X = 世界X;
                            当前敌人->骨骼点数组[i].位置.Y = 世界Y;
                            当前敌人->骨骼点数组[i].位置.Z = 世界Z;
                            
                            // 有效性检查（只保留要求的三个条件）：
                            bool 坐标有效 = true;
                            
                            // 条件1：xyz坐标必须全部不等于0
                            if (世界X == 0.0f && 世界Y == 0.0f && 世界Z == 0.0f) {
                                坐标有效 = false;
                            }
                            
                            // 条件2：不能是负数
                            if (世界X < 0.0f || 世界Y < 0.0f || 世界Z < 0.0f) {
                                坐标有效 = false;
                            }
                            
                            // 条件3：必须是数值（非NaN、非Inf）
                            if (!std::isfinite(世界X) || !std::isfinite(世界Y) || !std::isfinite(世界Z)) {
                                坐标有效 = false;
                            }
                            
                            // 设置有效性标志
                            当前敌人->骨骼点数组[i].有效 = 坐标有效;
                            
                        } else {
                            // 读取失败
                            当前敌人->骨骼点数组[i].有效 = false;
                            当前敌人->骨骼点数组[i].位置.X = 0.0f;
                            当前敌人->骨骼点数组[i].位置.Y = 0.0f;
                            当前敌人->骨骼点数组[i].位置.Z = 0.0f;
                        }
                    }
                }
            }
            
            
            
            bool 坐标有效 = true;
            if (当前敌人->坐标.X == 0 && 当前敌人->坐标.Y == 0 && 当前敌人->坐标.Z == 0) { 坐标有效 = false; } 
            else if (当前敌人->坐标.X < 0 || 当前敌人->坐标.Y < 0) { 坐标有效 = false; }                     
            bool 血量有效 = false;
            if (当前敌人->最大血量 > 0) { 血量有效 = true; }                        
            if (!坐标有效 || !血量有效) { continue; } 
            
           
            
            add.对象.敌人数量++;
        }
        
        
    }
    
    return 0;
}

static void* 数据分配线程(void* arg) {
    int last_game = -1;
    
    while (data_thread_running) {
        switch (current_game) {
            case 0: // 和平精英
                if (last_game != 0) {
                    last_game = 0;
                    std::cout << "\033[32m[+]\033[36m 和平精英\033[0m" << std::endl;                    
                    pid_t game_pid = Add->get_pid("com.tencent.tmgp.pubgmhd");
                    if (game_pid > 0) {
                        // 成功获取PID
                        std::cout << "\033[38;5;183m[~]\033[38;5;218m PID:\033[0m \033[38;5;198m" << game_pid << "\033[0m" << std::endl;                      
                        Add->initpid(game_pid);
                    }
                    add.libUE4 = Add->get_module_base(game_pid, "libUE4.so");
                    std::cout << "\033[38;5;183m[~]\033[38;5;180m libUE4 :\033[0m [ \033[38;5;198m" << std::hex << add.libUE4 << "\033[0m ]" << std::dec << std::endl;
                }
                和平精英();
                usleep(500000);
                break;
                
            case 1: // PUBGm
                if (last_game != 1) {
                    last_game = 1;
                    std::cout << "\033[32m[+]\033[36m PUBGm\033[0m" << std::endl;
                    pid_t game_pid = Add->get_pid("com.tencent.ig");
                    if (game_pid > 0) {
                        // 成功获取PID
                        std::cout << "\033[38;5;183m[~]\033[38;5;218m PID:\033[0m \033[38;5;198m" << game_pid << "\033[0m" << std::endl;                      
                        Add->initpid(game_pid);
                    }
                    add.libUE4 = Add->get_module_base(game_pid, "libUE4.so");
                    std::cout << "\033[38;5;183m[~]\033[38;5;180m libUE4 :\033[0m [ \033[38;5;198m" << std::hex << add.libUE4 << "\033[0m ]" << std::dec << std::endl;
                }
                break;
                
            case 2: // 三角洲[国服]
                if (last_game != 2) {
                    last_game = 2;
                    
                    
                    std::cout << "\033[32m[+]\033[36m 三角洲[国服]\033[0m" << std::endl;
                }
                break;
                
            case 3: // 三角洲[国际服]
                if (last_game != 3) {
                    last_game = 3;
                    std::cout << "\033[32m[+]\033[36m 三角洲[国际服]\033[0m" << std::endl;
                }
                break;
        }
        usleep(10000);
    }
    
    return NULL;
}

int 数据分配() {
    std::cout << "\033[32m[+]\033[36m 启动数据分配线程\033[0m" << std::endl;
    return pthread_create(&data_thread, NULL, 数据分配线程, NULL);
}

void 停止数据分配() {
    if (data_thread) {
        std::cout << "\033[35m[-]\033[33m 停止数据分配线程...\033[0m" << std::endl;
        data_thread_running = 0;
        pthread_join(data_thread, NULL);
        data_thread = 0;
        std::cout << "\033[32m[+]\033[36m 数据分配线程已停止\033[0m" << std::endl;
    }
}