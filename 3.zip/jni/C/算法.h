char* 读取类名(uintptr_t 类名ID, uintptr_t Gname地址) { // 类名算法
    static char 缓冲区[64] = {0};
    
    if (类名ID == 0 || Gname地址 == 0) {
        strcpy(缓冲区, "N/A");
        return 缓冲区;
    }
    
    try {
        uintptr_t FNameChunk = Add->read<uintptr_t>(Gname地址 + ((类名ID / 0x4000) * 0x8));
        if (FNameChunk == 0) return 缓冲区;
        
        uintptr_t FNameEntry = Add->read<uintptr_t>(FNameChunk + (类名ID % 0x4000) * 0x8);
        if (FNameEntry == 0) return 缓冲区;
        
        char temp[64] = {0};
        if (Add->read(FNameEntry + 0xC, temp, 63)) {
            strcpy(缓冲区, temp);
        }
    } catch (...) {
        strcpy(缓冲区, "Error");
    }
    
    return 缓冲区;
}

// 算法.h 中添加
char* 读取名字(uintptr_t 名字地址) {
    static char 缓冲区[64] = {0};
    
    if (名字地址 == 0) {
        strcpy(缓冲区, "N/A");
        return 缓冲区;
    }
    
    try {
        unsigned short buf16[32] = { 0 };
        if (!Add->read(名字地址, buf16, 28)) {
            strcpy(缓冲区, "读取失败");
            return 缓冲区;
        }
        
        char *pTempUTF8 = 缓冲区;
        char *pUTF8End = pTempUTF8 + 63;
        unsigned short *pTempUTF16 = buf16;
        
        while (pTempUTF16 < buf16 + 28 && pTempUTF8 < pUTF8End) {
            if (*pTempUTF16 <= 0x007F && pTempUTF8 + 1 < pUTF8End) {
                *pTempUTF8++ = (char) *pTempUTF16;
            } else if (*pTempUTF16 >= 0x0080 && *pTempUTF16 <= 0x07FF && pTempUTF8 + 2 < pUTF8End) {
                *pTempUTF8++ = (*pTempUTF16 >> 6) | 0xC0;
                *pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
            } else if (*pTempUTF16 >= 0x0800 && *pTempUTF16 <= 0xFFFF && pTempUTF8 + 3 < pUTF8End) {
                *pTempUTF8++ = (*pTempUTF16 >> 12) | 0xE0;
                *pTempUTF8++ = ((*pTempUTF16 >> 6) & 0x3F) | 0x80;
                *pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
            } else {
                break;
            }
            pTempUTF16++;
        }
        *pTempUTF8 = '\0';
        
        // 如果名字为空，显示默认值
        if (strlen(缓冲区) == 0) {
            strcpy(缓冲区, "未知");
        }
    } catch (...) {
        strcpy(缓冲区, "Error");
    }
    
    return 缓冲区;
}