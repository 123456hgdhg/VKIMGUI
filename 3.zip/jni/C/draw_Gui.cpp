
#include "draw.h"
#include "数据结构体.h"
#include "My_font/zh_Font.h"
#include "My_font/fontawesome-brands.h"
#include "My_font/fontawesome-regular.h"
#include "My_font/fontawesome-solid.h"
#include "My_font/gui_icon.h"  
#include "My_icon/pic_ZhenAiKun_png.h"
#include <iostream>
#include <memory>

extern "C" {
    extern 数据 add;
}

// 通用打印宏
#define PRINT_VALUE(label, format, value) \
    printf("\033[38;5;183m[~]\033[38;5;180m %s :\033[0m [ \033[38;5;198m" format "\033[0m ]\n", label, value)

bool permeate_record = false;
bool permeate_record_ini = false;
struct Last_ImRect LastCoordinate = {0, 0, 0, 0};

int current_game = 0;
const char* game_names[] = {
    "和平精英",
    "和平精英[国际服] - 未添加", 
    "三角洲[国服] - 未添加",
    "三角洲[国际服] - 未添加"
};

std::unique_ptr<AndroidImgui> graphics;
ANativeWindow *window = NULL; 
android::ANativeWindowCreator::DisplayInfo displayInfo;// 屏幕信息
ImGuiWindow *g_window = NULL;// 窗口信息
int abs_ScreenX = 0, abs_ScreenY = 0;// 绝对屏幕X _ Y
int native_window_screen_x = 0, native_window_screen_y = 0;

TextureInfo Aekun_image{};

ImFont* zh_font = NULL;
ImFont* icon_font_0 = NULL;
ImFont* icon_font_1 = NULL;
ImFont* icon_font_2 = NULL;

bool M_Android_LoadFont(float SizePixels) {
    ImGuiIO &io = ImGui::GetIO();
    
    //ImFontConfig config; //oppo字体部分
    //config.FontDataOwnedByAtlas = false;
    //config.SizePixels = SizePixels;
    //config.OversampleH = 1;
    //::zh_font = io.Fonts->AddFontFromMemoryTTF((void *)OPPOSans_H, OPPOSans_H_size, 0.0f, &config, io.Fonts->GetGlyphRangesChineseFull());    
    ////io.Fonts->AddFontDefault(&config);

	static const ImWchar icons_ranges[] = {ICON_MIN_FA, ICON_MAX_FA, 0};
    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 3.0;
    icons_config.OversampleV = 3.0;		
    icons_config.SizePixels = SizePixels;
    //icons_config.GlyphOffset.y += 7.0f; // 通过 GlyphOffset 调整单个字形偏移量，向下偏移 size 像素
	::icon_font_0 = io.Fonts->AddFontFromMemoryCompressedTTF((const void *)&font_awesome_brands_compressed_data, sizeof(font_awesome_brands_compressed_data), 0.0f, &icons_config, icons_ranges);
	::icon_font_1 = io.Fonts->AddFontFromMemoryCompressedTTF((const void *)&font_awesome_regular_compressed_data, sizeof(font_awesome_regular_compressed_data), 0.0f, &icons_config, icons_ranges);
	::icon_font_2 = io.Fonts->AddFontFromMemoryCompressedTTF((const void *)&font_awesome_solid_compressed_data, sizeof(font_awesome_solid_compressed_data), 0.0f, &icons_config, icons_ranges);

    io.Fonts->AddFontDefault();
    return zh_font != nullptr;
}
void init_My_drawdata() {
    ImGui::StyleColorsLight(); //白色
    ImGui::My_Android_LoadSystemFont(25.0f); //(加载系统字体 安卓15完美适配)
    M_Android_LoadFont(25.0f); //加载字体(还有图标)
    ImGui::GetStyle().ScaleAllSizes(3.25f);
    ::Aekun_image = graphics->LoadTextureFromMemory((void *)picture_ZhenAiKun_PNG_H, sizeof(picture_ZhenAiKun_PNG_H));
}


void screen_config() {
    ::displayInfo = android::ANativeWindowCreator::GetDisplayInfo();
}

void drawBegin() {
    if (::permeate_record_ini) {
        LastCoordinate.Pos_x = ::g_window->Pos.x;
        LastCoordinate.Pos_y = ::g_window->Pos.y;
        LastCoordinate.Size_x = ::g_window->Size.x;
        LastCoordinate.Size_y = ::g_window->Size.y;

        graphics->Shutdown();
        android::ANativeWindowCreator::Destroy(::window);
        ::window = android::ANativeWindowCreator::Create("test_sysGui", native_window_screen_x, native_window_screen_y, permeate_record);
        graphics->Init_Render(::window, native_window_screen_x, native_window_screen_y);
        ::init_My_drawdata(); //初始化绘制数据
    } 


    static uint32_t orientation = -1;
    screen_config();
    if (orientation != displayInfo.orientation) {
        orientation = displayInfo.orientation;
        Touch::setOrientation((int)displayInfo.orientation);
        if (g_window != NULL) {
            g_window->Pos.x = 100;
            g_window->Pos.y = 125;        
        }        
        //cout << " width:" << displayInfo.width << " height:" << displayInfo.height << " orientation:" << displayInfo.orientation << endl;
    }
}



void Layout_tick_UI(bool *main_thread_flag) {
    static bool show_demo_window = false;
        
    ImGui::Begin("kali V1.001", main_thread_flag);
            
    // 宽度自适应：使用窗口可用宽度
    float available_width = ImGui::GetContentRegionAvail().x;
    float selector_width = available_width * 1.0f;  // 占满可用宽度
    
    ImGui::PushItemWidth(selector_width);
    
    // 增加高度的关键：增加FramePadding的y值
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(10, 17));  // 增加垂直内边距到15
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8, 12));     // 增加项目间距的垂直距离
    
    // 推入自定义样式 - 恢复原样，不改变悬停和激活颜色
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.90f, 0.90f, 0.90f, 0.80f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.90f, 0.90f, 0.90f, 0.80f)); // 悬停时不变
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0.90f, 0.90f, 0.90f, 0.80f));  // 激活时不变
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.10f, 0.10f, 0.10f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.75f, 0.75f, 0.75f, 0.80f));
    
    // 调整拖拽灵敏度
    float drag_speed = 0.003f;
    
    // 使用DragInt，显示游戏名称
    if (ImGui::DragInt("##游戏选择", &current_game, drag_speed, 0, 3, game_names[current_game])) {
        // 确保值在范围内
        if (current_game < 0) current_game = 0;
        if (current_game > 3) current_game = 3;
    }

    // 弹出样式
    ImGui::PopStyleColor(5);
    ImGui::PopStyleVar(2);  // 弹出FramePadding和ItemSpacing
    ImGui::PopItemWidth();
    
    // 按钮布局
    if (ImGui::Button("打印基本信息", ImVec2(150, 50))) {        
        std::cout << "\033c\033[3J" << std::flush;        
        std::cout << "\n";
        PRINT_VALUE("World", "%lx", add.世界);
        PRINT_VALUE("Gname", "%lx", add.Gname);
        PRINT_VALUE("Matrix", "%lx", add.矩阵_0);
        std::cout << "\n";
        PRINT_VALUE("地址", "%lx", add.自己数据.自身.地址);
        std::cout << "\n";
        PRINT_VALUE("类名", "%s", add.自己数据.自身.类名);
        PRINT_VALUE("名字", "%s", add.自己数据.自身.名字字符串);
        std::cout << "\n";
        PRINT_VALUE("弹夹子弹", "%d", add.自己数据.自身.弹夹子弹);
        PRINT_VALUE("总备弹量", "%d", add.自己数据.自身.总备弹量);
        std::cout << "\n";
        PRINT_VALUE("X", "%f", add.自己数据.自身.坐标.X);
        PRINT_VALUE("Y", "%f", add.自己数据.自身.坐标.Y);
        PRINT_VALUE("Z", "%f", add.自己数据.自身.坐标.Z);
        std::cout << "\n";
        PRINT_VALUE("正常血量", "%f", add.自己数据.自身.正常血量);
        PRINT_VALUE("到地血量", "%f", add.自己数据.自身.到地血量);
        PRINT_VALUE("最大血量", "%f", add.自己数据.自身.最大血量);
        std::cout << "\n";
        PRINT_VALUE("人机判断", "%d", add.自己数据.自身.人机判断);
        PRINT_VALUE("人物判断", "%f", add.自己数据.自身.人物判断);
        std::cout << "\n";
        PRINT_VALUE("状态", "%d", add.自己数据.自身.状态);
        PRINT_VALUE("队伍ID", "%d", add.自己数据.自身.队伍ID);
        PRINT_VALUE("类名ID", "%d", add.自己数据.自身.类名ID);
        PRINT_VALUE("当前武器", "%d", add.自己数据.自身.当前武器);
        PRINT_VALUE("手持握把", "%d", add.自己数据.自身.手持握把);
        std::cout << "\n";
        PRINT_VALUE("Fov", "%f", add.自己数据.自身.Fov);
        PRINT_VALUE("抑制力", "%f", add.自己数据.自身.抑制力);
        PRINT_VALUE("准心Y", "%f", add.自己数据.自身.准心Y);
        std::cout << "\n";
        // PRINT_VALUE("当前关卡", "%f", add.当前关卡);
        PRINT_VALUE("对象数组", "%lx", add.对象数组);
        PRINT_VALUE("对象数组数量", "%d", add.对象数组数量);
    }
    if (ImGui::Button("敌人", ImVec2(150, 50))) {
        std::cout << "\033c\033[3J" << std::flush;
        std::cout << "\n\033[32m[+]\033[36m 敌人信息\033[0m\n";
        
        for (int i = 0; i < add.对象.敌人数量 && i < 100; i++) {                        
            std::cout << "\n\033[38;5;183m[~]\033[38;5;208m 敌人 " << i << ":\033[0m\n";
            std::cout << "\n";
            PRINT_VALUE("地址", "%lx", add.对象.敌人数组[i].地址);
            std::cout << "\n";
            PRINT_VALUE("弹夹子弹", "%d", add.对象.敌人数组[i].弹夹子弹);
            PRINT_VALUE("总备弹量", "%d", add.对象.敌人数组[i].总备弹量);
            std::cout << "\n";
            PRINT_VALUE("X", "%f", add.对象.敌人数组[i].坐标.X);
            PRINT_VALUE("Y", "%f", add.对象.敌人数组[i].坐标.Y);
            PRINT_VALUE("Z", "%f", add.对象.敌人数组[i].坐标.Z);
            std::cout << "\n";
            PRINT_VALUE("正常血量", "%f", add.对象.敌人数组[i].正常血量);
            PRINT_VALUE("到地血量", "%f", add.对象.敌人数组[i].到地血量);
            PRINT_VALUE("最大血量", "%f", add.对象.敌人数组[i].最大血量);
            std::cout << "\n";
            PRINT_VALUE("人机判断", "%d", add.对象.敌人数组[i].人机判断);
            PRINT_VALUE("人物判断", "%f", add.对象.敌人数组[i].人物判断);
            std::cout << "\n";
            PRINT_VALUE("状态", "%d", add.对象.敌人数组[i].状态);
            PRINT_VALUE("队伍ID", "%d", add.对象.敌人数组[i].队伍ID);
            PRINT_VALUE("类名ID", "%d", add.对象.敌人数组[i].类名ID);
            PRINT_VALUE("类名", "%s", add.对象.敌人数组[i].类名);
            PRINT_VALUE("名字", "%s", add.对象.敌人数组[i].名字字符串);
            
            PRINT_VALUE("当前武器", "%d", add.对象.敌人数组[i].当前武器);
            PRINT_VALUE("手持握把", "%d", add.对象.敌人数组[i].手持握把);
            std::cout << "\n";
            PRINT_VALUE("Fov", "%f", add.对象.敌人数组[i].Fov);
            PRINT_VALUE("抑制力", "%f", add.对象.敌人数组[i].抑制力);
            PRINT_VALUE("准心Y", "%f", add.对象.敌人数组[i].准心Y);
            
            
        }
        
        std::cout << "\n\033[32m[+]\033[36m 总计敌人数量: \033[0m" << add.对象.敌人数量 << std::endl;
    }
   
    // 在 Layout_tick_UI 函数中修改骨骼点显示按钮
    if (ImGui::Button("显示骨骼点", ImVec2(150, 50))) {
        std::cout << "\033c\033[3J" << std::flush;
        printf("\n\033[32m[+]\033[36m 敌人骨骼点信息\033[0m\n");
        
        // 检查是否有敌人
        if (add.对象.敌人数量 > 0) {
            // 获取第一个敌人
            敌人结构* 第一个敌人 = &add.对象.敌人数组[0];
            
            printf("\n\033[38;5;183m[~]\033[38;5;208m 第一个敌人的骨骼点信息:\033[0m\n");
            printf("\033[38;5;183m[~]\033[38;5;180m 网格地址 :\033[0m [ \033[38;5;198m%lx\033[0m ]\n", 第一个敌人->网格地址);
            printf("\033[38;5;183m[~]\033[38;5;180m 骨骼点数量 :\033[0m [ \033[38;5;198m%d\033[0m ]\n\n", 第一个敌人->骨骼点数量);
            
            // 计算有效骨骼点数量
            int 有效骨骼点 = 0;
            for (int i = 0; i < 第一个敌人->骨骼点数量; i++) {
                if (第一个敌人->骨骼点数组[i].有效) {
                    有效骨骼点++;
                }
            }
            printf("\033[38;5;183m[~]\033[38;5;180m 有效骨骼点 :\033[0m [ \033[38;5;198m%d\033[0m ]\n\n", 有效骨骼点);
            
            // 打印所有骨骼点坐标（移除数量限制）
            printf("\033[38;5;183m[~]\033[38;5;208m 所有骨骼点坐标:\033[0m\n");
            
            for (int i = 0; i < 第一个敌人->骨骼点数量; i++) {
                骨骼点* 当前骨骼点 = &第一个敌人->骨骼点数组[i];
                
                printf("\033[38;5;183m[~]\033[38;5;180m 骨骼点 %d:\033[0m ", i);
                
                if (当前骨骼点->有效) {
                    printf("[ \033[38;5;46m有效\033[0m ] ");
                    printf("X: \033[38;5;198m%.8f\033[0m, Y: \033[38;5;198m%.8f\033[0m, Z: \033[38;5;198m%.8f\033[0m\n", 
                           当前骨骼点->位置.X, 当前骨骼点->位置.Y, 当前骨骼点->位置.Z);
                } else {
                    printf("[ \033[38;5;196m无效\033[0m ] ");
                    printf("X: \033[38;5;198m%.8f\033[0m, Y: \033[38;5;198m%.8f\033[0m, Z: \033[38;5;198m%.8f\033[0m\n", 
                           当前骨骼点->位置.X, 当前骨骼点->位置.Y, 当前骨骼点->位置.Z);
                }
            }
            
            // 显示关键骨骼点索引信息
            printf("\n\033[38;5;183m[~]\033[38;5;208m 关键骨骼点信息:\033[0m\n");
            
            // 头部骨骼（通常索引5或6）
            if (第一个敌人->骨骼点数量 > 6 && 第一个敌人->骨骼点数组[5].有效) {
                printf("\033[38;5;183m[~]\033[38;5;180m 头部(索引5):\033[0m ");
                printf("X: \033[38;5;198m%.8f\033[0m, Y: \033[38;5;198m%.8f\033[0m, Z: \033[38;5;198m%.8f\033[0m\n", 
                       第一个敌人->骨骼点数组[5].位置.X, 
                       第一个敌人->骨骼点数组[5].位置.Y,
                       第一个敌人->骨骼点数组[5].位置.Z);
            }
            
            // 胸部骨骼（通常索引3或4）
            if (第一个敌人->骨骼点数量 > 4 && 第一个敌人->骨骼点数组[3].有效) {
                printf("\033[38;5;183m[~]\033[38;5;180m 胸部(索引3):\033[0m ");
                printf("X: \033[38;5;198m%.8f\033[0m, Y: \033[38;5;198m%.8f\033[0m, Z: \033[38;5;198m%.8f\033[0m\n", 
                       第一个敌人->骨骼点数组[3].位置.X, 
                       第一个敌人->骨骼点数组[3].位置.Y,
                       第一个敌人->骨骼点数组[3].位置.Z);
            }
            
            // 盆骨骨骼（通常索引0或1）
            if (第一个敌人->骨骼点数量 > 1 && 第一个敌人->骨骼点数组[1].有效) {
                printf("\033[38;5;183m[~]\033[38;5;180m 盆骨(索引1):\033[0m ");
                printf("X: \033[38;5;198m%.8f\033[0m, Y: \033[38;5;198m%.8f\033[0m, Z: \033[38;5;198m%.8f\033[0m\n", 
                       第一个敌人->骨骼点数组[1].位置.X, 
                       第一个敌人->骨骼点数组[1].位置.Y,
                       第一个敌人->骨骼点数组[1].位置.Z);
            }
            
        } else {
            printf("\n\033[31m[!]\033[33m 没有找到敌人，无法显示骨骼点信息\033[0m\n");
        }
    }
   
   
    ImGui::Checkbox("演示窗口", &show_demo_window);
    g_window = ImGui::GetCurrentWindow();
    ImGui::End();
    
    if (show_demo_window) {
        ImGui::ShowDemoWindow(&show_demo_window);
    }
}