// 数据结构体.h
struct 坐标 {float X, Y, Z;};
struct 屏幕坐标 {float X, Y;};

struct 骨骼点 {
    坐标 位置;
    bool 有效;
};




struct 通用结构 {        
    uintptr_t 地址;
    uintptr_t 名字;
    int   状态;
    int   当前武器; 
    int   队伍ID; 
    int   总备弹量; 
    int   弹夹子弹;
    int   人机判断;
    int   手持握把;
    int   类名ID;
    float Fov;
    float 正常血量;
    float 到地血量;
    float 最大血量;
    float 抑制力;
    float 准心Y;
    float 人物判断;     
    坐标 坐标;
    
    char 名字字符串[64]; 
    
    骨骼点 骨骼点数组[128];
    int 骨骼点数量;
    uintptr_t 网格地址;
    
    char 类名[64]; 
};

// 使用typedef创建不同类型的"通用结构"别名
typedef 通用结构 敌人结构;
typedef 通用结构 物品结构;
typedef 通用结构 载具结构;
typedef 通用结构 玩家结构;  // 添加玩家结构类型

// 然后在对象数据中定义
struct 对象数据 {
    uintptr_t 对象地址;
    float 人物判断;    
    int 敌人数量; 
    int 类名ID;
    
    敌人结构 通用结构1;    // 专门存放敌人通用数据
    物品结构 通用结构2;    // 专门存放物品通用数据
    载具结构 通用结构3;    // 专门存放载具通用数据
    
    敌人结构 敌人数组[100];
    物品结构 物品数组[800];
    载具结构 载具数组[100];
};

struct 数据{
    uintptr_t libUE4, 世界, 矩阵_0, 矩阵_1, Gname;    
    uintptr_t 当前关卡, 对象数组, 对象数组数量;    
    struct 自己数据{
        玩家结构 自身;      // 使用玩家结构存放自身数据
        屏幕坐标 屏幕坐标;   // 额外的屏幕坐标信息
    }自己数据;
    
    对象数据 对象;
};