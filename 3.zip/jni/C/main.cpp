// main.cpp - 驱动读写工具 v1.0
#include "draw.h"    
#include "AndroidImgui.h"     
#include "GraphicsManager.h" 
#include <cmath>  
#include "数据结构体.h"
#include "驱动对接.h"
#include "数据.h"
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <memory>
#include <string>
#include <limits>

// 声明外部变量
extern std::unique_ptr<AndroidImgui> graphics;
extern ANativeWindow *window;
extern android::ANativeWindowCreator::DisplayInfo displayInfo;
extern ImGuiWindow *g_window;
extern int abs_ScreenX, abs_ScreenY;
extern int native_window_screen_x, native_window_screen_y;

// 全局驱动对象
DriverInterface* Add = nullptr;
数据 add;

// 后台进程创建
void CreateBackgroundProcess() {
    pid_t pid = fork();
    if (pid < 0) return;
    if (pid > 0) exit(0);
    setsid();
}

// 显示驱动选择菜单
int ShowDriverMenu() {
    std::cout << "\033[2J\033[1;1H";             
    std::cout << "\033\n[35m[-]\033[33m 选择驱动:\033[0m" << std::endl;
    std::cout << "\033[32m[+]\033[36m 1. KMA v6.12.503\033[0m" << std::endl;
    std::cout << "\033[32m[+]\033[36m 2. QX驱动1 (读取慢,兼容性高)\033[0m" << std::endl;
    std::cout << "\033[32m[+]\033[36m 3. GT驱动\033[0m" << std::endl;
    std::cout << "\033[32m[+]\033[36m 4. rt-dev驱动\033[0m" << std::endl;
    std::cout << "\033[32m[+]\033[36m 5. rt-proc驱动\033[0m" << std::endl;
    std::cout << "\033[32m[+]\033[36m 6. QX驱动2\033[0m" << std::endl;
    std::cout << "\033[94m[-]\033[93m 请输入选择 [1-6]: \033[0m";
    
    int choice;
    std::cin >> choice;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    return choice;
}

// 初始化驱动
bool InitDriver(int driver_type) {
    std::cout << "\033[35m[-]\033[33m 正在初始化驱动...\033[0m" << std::endl;
    
    Add = new DriverInterface(static_cast<DriverType>(driver_type));
    
    if (Add && Add->is_valid()) {
        std::cout << "\033[32m[+]\033[36m 驱动初始化成功!\033[0m" << std::endl;
        return true;
    } else {
        std::cout << "\033[31m[!]\033[33m 驱动初始化失败!\033[0m" << std::endl;
        return false;
    }
}

int main(int argc, char *argv[]) {
    std::cout << "\033[2J\033[1;1H";
    std::cout << "\033\n[1;36m═════════════TG @Brother Hua\033[0m" << std::endl;
       
    // 选择执行模式
    std::cout << "\033[35m[-]\033[33m 选择执行模式:\033[0m" << std::endl;
    std::cout << "\033[32m[+]\033[36m 1. 有后台\033[0m" << std::endl;
    std::cout << "\033[32m[+]\033[36m 2. 无后台\033[0m" << std::endl;
    std::cout << "\033[94m[-]\033[93m 请输入选择 [1-2]: \033[0m";
    
    int mode_choice;
    std::cin >> mode_choice;
    bool permeate_record = (mode_choice == 2);
    
    // 验证模式选择
    if (mode_choice < 1 || mode_choice > 2) {
        std::cout << "\033[31m[!]\033[33m 执行模式选择错误，程序退出\033[0m" << std::endl;
        return 1;
    }
    
    // 选择驱动类型
    int driver_choice = ShowDriverMenu();
    
    // 验证驱动选择
    if (driver_choice < 1 || driver_choice > 6) {
        std::cout << "\033[31m[!]\033[33m 驱动选择错误，程序退出\033[0m" << std::endl;
        return 1;
    }
    
    // 初始化驱动
    bool driver_initialized = InitDriver(driver_choice);
    
    // 如果驱动初始化失败，直接退出
    if (!driver_initialized) {
        std::cout << "\033[31m[!]\033[33m 驱动初始化失败，程序退出\033[0m" << std::endl;
        if (Add) {
            delete Add;
            Add = nullptr;
        }
        return 1;
    }
    
    std::cout << "\033[32m[+]\033[36m 驱动功能已就绪\033[0m" << std::endl;
    
    if (permeate_record) CreateBackgroundProcess();
    
    // 初始化图形界面
    ::graphics = GraphicsManager::getGraphicsInterface(GraphicsManager::VULKAN);
    ::screen_config();
    ::native_window_screen_x = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    ::native_window_screen_y = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    ::abs_ScreenX = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    ::abs_ScreenY = (::displayInfo.height < ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    ::window = android::ANativeWindowCreator::Create("test", native_window_screen_x, native_window_screen_y, permeate_record);
    graphics->Init_Render(::window, native_window_screen_x, native_window_screen_y);
    Touch::Init({(float)::abs_ScreenX, (float)::abs_ScreenY}, false);
    Touch::setOrientation(displayInfo.orientation);
    ::init_My_drawdata();

    // 启动数据分配线程
    数据分配();

    // 主循环
    static bool flag = true;
    while (flag) {
        drawBegin();
        if (!permeate_record) android::ANativeWindowCreator::ProcessMirrorDisplay();
        graphics->NewFrame();
        Layout_tick_UI(&flag);
        graphics->EndFrame();        
    }
    
    // 清理资源
    停止数据分配(); // 安全停止线程
    graphics->Shutdown();
    android::ANativeWindowCreator::Destroy(::window);
    if (Add) {
        Add->destroy();
        delete Add;
        Add = nullptr;
    }
    
    std::cout << "\033[32m[+]\033[36m 程序正常退出\033[0m" << std::endl;
    return 0;
}